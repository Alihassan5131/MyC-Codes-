#include <iostream>
#include <string>
using namespace std;

struct Student
{
    int id;
    string name;
    int age;
    string major;
    float gpa;
    Student* next;
};

void addStudent(Student*& head);
void displayStudents(const Student* head);
Student* findStudentById(Student* head, int id);
void deleteStudentById(Student*& head, int id);
void updateStudent(Student* head, int id);
void clearList(Student*& head);

int main()
{
    Student* head = nullptr;
    int choice;

    do
    {
        cout << "\n=== Student Record Management System ===\n";
        cout << "1. Add Student Record\n";
        cout << "2. Display All Student Records\n";
        cout << "3. Search Student by ID\n";
        cout << "4. Update Student Record\n";
        cout << "5. Delete Student Record\n";
        cout << "6. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice)
        {
            case 1:
                addStudent(head);
                break;
            case 2:
                displayStudents(head);
                break;
            case 3:
            {
                int id;
                cout << "Enter student ID to search: ";
                cin >> id;
                Student* student = findStudentById(head, id);
                if (student)
                {
                    cout << "\nStudent found:\n";
                    cout << "ID: " << student->id << "\n";
                    cout << "Name: " << student->name << "\n";
                    cout << "Age: " << student->age << "\n";
                    cout << "Major: " << student->major << "\n";
                    cout << "GPA: " << student->gpa << "\n";
                }
                else
                {
                    cout << "Student with ID " << id << " not found.\n";
                }
                break;
            }
            case 4:
            {
                int id;
                cout << "Enter student ID to update: ";
                cin >> id;
                updateStudent(head, id);
                break;
            }
            case 5:
            {
                int id;
                cout << "Enter student ID to delete: ";
                cin >> id;
                deleteStudentById(head, id);
                break;
            }
            case 6:
                cout << "Exiting program.\n";
                break;
            default:
                cout << "Invalid choice. Please try again.\n";
                break;
        }
    }
    while (choice != 6);

    clearList(head);
    return 0;
}

void addStudent(Student*& head)
{
    int id;
    cout << "Enter student ID: ";
    cin >> id;
    if (findStudentById(head, id))
    {
        cout << "A student with ID " << id << " already exists.\n";
        return;
    }

    Student* newStudent = new Student();
    newStudent->id = id;
    cout << "Enter student name: ";
    cin >> newStudent->name;
    cout << "Enter student age: ";
    cin >> newStudent->age;
    cout << "Enter student major: ";
    cin >> newStudent->major;
    cout << "Enter student GPA: ";
    cin >> newStudent->gpa;
    newStudent->next = nullptr;

    if (!head)
    {
        head = newStudent;
    }
    else
    {
        Student* temp = head;
        while (temp->next)
            temp = temp->next;
        temp->next = newStudent;
    }

    cout << "Student record added successfully.\n";
}

void displayStudents(const Student* head)
{
    if (!head)
    {
        cout << "No student records available.\n";
        return;
    }

    cout << "\n--- Student Records ---\n";
    const Student* temp = head;
    while (temp)
    {
        cout << "ID: " << temp->id << " | ";
        cout << "Name: " << temp->name << " | ";
        cout << "Age: " << temp->age << " | ";
        cout << "Major: " << temp->major << " | ";
        cout << "GPA: " << temp->gpa << "\n";
        temp = temp->next;
    }
}

Student* findStudentById(Student* head, int id)
{
    Student* temp = head;
    while (temp)
    {
        if (temp->id == id)
            return temp;
        temp = temp->next;
    }
    return nullptr;
}

void deleteStudentById(Student*& head, int id)
{
    if (!head)
    {
        cout << "No records to delete.\n";
        return;
    }

    if (head->id == id)
    {
        Student* toDelete = head;
        head = head->next;
        delete toDelete;
        cout << "Student record deleted.\n";
        return;
    }

    Student* prev = head;
    Student* current = head->next;
    while (current)
    {
        if (current->id == id)
        {
            prev->next = current->next;
            delete current;
            cout << "Student record deleted.\n";
            return;
        }
        prev = current;
        current = current->next;
    }

    cout << "Student with ID " << id << " not found.\n";
}

void updateStudent(Student* head, int id)
{
    Student* student = findStudentById(head, id);
    if (!student)
    {
        cout << "Student with ID " << id << " not found.\n";
        return;
    }

    cout << "Enter new name (current: " << student->name << "): ";
    cin >> student->name;
    cout << "Enter new age (current: " << student->age << "): ";
    cin >> student->age;
    cout << "Enter new major (current: " << student->major << "): ";
    cin >> student->major;
    cout << "Enter new GPA (current: " << student->gpa << "): ";
    cin >> student->gpa;

    cout << "Student record updated successfully.\n";
}

void clearList(Student*& head)
{
    while (head)
    {
        Student* temp = head;
        head = head->next;
        delete temp;
    }
}
