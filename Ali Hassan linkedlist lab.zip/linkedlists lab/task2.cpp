#include <iostream>
using namespace std;
// Define the structure for a node
struct Node
{
 int data;
 Node* next;
};
int main()
{
    int in_fl=0,button=0;
    int data[5];
    
        Node* first;
        Node* second;
        Node* third;
        Node* fourth;
        Node* fifth;
         cout<<"press 1 to create new node: ";
         cin>>in_fl;
         if(in_fl=1)
        {
            
            first= new Node();
            cout<<"Enter data of the node: ";
            cin>>first->data;
            
 

           cout<<"\npress 1 to add next Element or 0 to finish : ";
           cin>>button;
           if(button==1)
           {
            second = new Node();
            first->next = second;
            cout<<"Enter data of the second: ";
            cin>>second->data;

            button=0;

          }
          else{
             first->next = NULL;

          }
          cout<<"\npress 1 to add next Element or 0 to finish : ";
           cin>>button;
           if(button==1)
           {
             third = new Node();
            second->next = third;
             cout<<"Enter data of the third: ";
            cin>>third->data;


            button=0;

          }
          else{
             second->next = NULL;

          }
          cout<<"\npress 1 to add next Element or 0 to finish : ";
           cin>>button;
           if(button==1)
           {
             fourth = new Node();
            third->next = fourth;
             cout<<"Enter data of the fourth: ";
            cin>>fourth->data;


            button=0;

          }
          else{
             third->next = NULL;

          }
          cout<<"\npress 1 to add next Element or 0 to finish : ";
           cin>>button;
           if(button==1)
           {
             fifth = new Node();
            fourth->next = fifth;
             cout<<"Enter data of the third: ";
            cin>>fifth->data;
            fifth->next=NULL;


            button=0;

          }
          else{
             fourth->next = NULL;

          }


        }
    

    
   
 Node* temp =first;
 
 cout << "\n\nLinked List Elements: ";
 while (temp != NULL)
 {
 cout << temp->data << "-->";
 temp = temp->next;
 }
 cout <<"NULL"<< endl;

 
}