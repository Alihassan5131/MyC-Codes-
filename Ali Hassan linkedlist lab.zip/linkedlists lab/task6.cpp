#include <iostream>
using namespace std;
// Define the structure for a node
struct Node
{
 int data;
 Node* next;
};

 bool search(Node* head, int value);
int main()
{
    
 

 Node* first = new Node();
 Node* second = new Node();
 Node* third = new Node();
Node* fourth = new Node();
Node* fifth = new Node();
// Assign data and link the nodes
 first->data = 10;
 first->next = second;
 second->data = 20;
 second->next = third;
 third->data = 30;
 third->next = fourth;
 fourth->data = 40;
 fourth->next = fifth;
 fifth->data = 50;
 fifth->next = NULL;



 
Node* temp = first;
 cout << "\n\nLinked List Elements : ";
 while (temp != NULL)
 {
 cout << temp->data << "-->";
 temp = temp->next;
 }
 cout <<"NULL\n"<< endl;
int val;
 cout << "\n\nWich Element do you want to find : ";
 cin>> val;
 if(search(first,val)==1)
 {
    cout<<"value found";
 }
 else
 {
    cout<<"value not found";
 }
 return 0;
}
 bool search(Node* head, int value)
 {
    Node* temp = head;
    bool flag=0;
 
 while (temp!=NULL )
    {
        
        if (temp->data==value)
        {
            flag=1;
        }
        temp=temp->next;
        
    }
    return flag;

    

 }
 