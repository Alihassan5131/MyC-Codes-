#include <iostream>
using namespace std;
// Define the structure for a node
struct Node
{
 int data;
 Node* next;
};
void insertBeginning(Node*& head, int value);
void insertend(Node*& head, int value);
int main()
{
    
 Node* head;

 Node* first = new Node();
 Node* second = new Node();
 Node* third = new Node();
Node* fourth = new Node();
Node* fifth = new Node();
// Assign data and link the nodes
 first->data = 10;
 first->next = second;
 second->data = 20;
 second->next = third;
 third->data = 30;
 third->next = fourth;
 fourth->data = 40;
 fourth->next = fifth;
 fifth->data = 50;
 fifth->next = NULL;



 Node* temp = first;
 cout << "\n\nLinked List Elements befor insertion at end : ";
 while (temp != NULL)
 {
 cout << temp->data << "-->";
 temp = temp->next;
 }
 cout <<"NULL\n"<< endl;
 insertend(first,200);
 insertend(first,400);
 insertend(first,500);
  


 temp = first;
 cout << "\n\nLinked List Elements After inserting 3 elements at the end : ";
 while (temp != NULL)
 {
 cout << temp->data << "-->";
 temp = temp->next;
 }
 cout <<"NULL\n"<< endl;


 
 return 0;
}
void insertBeginning(Node*& head, int value)
{
  Node* newnode= new Node();
  newnode->data=value;
  newnode->next=head;
  head=newnode;  
}
void insertend(Node*& head, int value)
{
  Node* last=head;
  while(last->next!=NULL)
  {
    last=last->next;
  }
  Node* newnode= new Node();
  newnode->data=value;
  newnode->next=NULL;
  last->next=newnode;
  last=newnode;  
}