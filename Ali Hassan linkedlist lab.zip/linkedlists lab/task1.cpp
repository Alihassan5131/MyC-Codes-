#include <iostream>
using namespace std;
// Define the structure for a node
struct Node
{
 int data;
 Node* next;
};
int main()
{

 Node* first = new Node();
 Node* second = new Node();
 Node* third = new Node();
Node* fourth = new Node();
Node* fifth = new Node();
// Assign data and link the nodes
 first->data = 10;
 first->next = second;
 second->data = 20;
 second->next = third;
 third->data = 30;
 third->next = fourth;
 fourth->data = 40;
 fourth->next = fifth;
 fifth->data = 50;
 fifth->next = NULL;

 Node* temp = first;
 cout << "Linked List Elements: ";
 while (temp != NULL)
 {
 cout << temp->data << "-->";
 temp = temp->next;
 }
 cout <<"NULL"<< endl;

 delete first;
 delete second;
 delete third;
 delete fourth;
 delete fifth;
 return 0;
}