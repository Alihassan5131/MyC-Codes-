#include <iostream>
using namespace std;
struct processor
{
string name;
int cores;
float freq;
int cache_size;

};
int main()
{
processor p[3];

for(int i=0;i<3;i++)
{
    cout<<"Processor # "<<i;
    cout << "\n\nEnter name of the processor : " ; 
    cin>>p[i].name ;
    cout << "\nEnter number of cores : " ;
    cin>>p[i].cores;
    cout << "\nEnter frequency in MHz : " ;
    cin>> p[i].freq ;
    cout << "\nEnter cache size in KB : " ;
    cin>>p[i].cache_size;


}
for(int i=0;i<3;i++)
{
    cout<<"Displaying processor "<<i<<"data: ";
    cout<<"\n\nprocessor name: "<<p[i].name;
    cout<<"\nOperating frequencey: "<<p[i].freq<<"MHz";
    cout<<"\nnumber of cores: "<<p[i].freq;
    cout<<"\ncache size: "<<p[i].cache_size<<"KB";

}





return 0;
}