#include <iostream>
#include <string>
using namespace std;
struct timing
{
    float rising_time;
    float setup_time;
    float hold_time;
 
};
struct DFF
{
    timing df_timing;

 
};

int main()
{
   DFF dff1;
   dff1.df_timing={3.4,5.6,7.8};
   cout<<"\nRising time =: "<<dff1.df_timing.rising_time;
   cout<<"\nsetup time =: "<<dff1.df_timing.setup_time;
   cout<<"\nholding time =: "<<dff1.df_timing.hold_time;



}
 