#include <iostream>
using namespace std;
struct processor
{
string name;
int cores;
float freq;
int cache_size;

};

void displayProcessor(processor p1[],int size);
int main()
{
processor p[3];

for(int i=0;i<3;i++)
{
    cout<<"Processor # "<<i;
    cout << "\n\nEnter name of the processor : " ; 
    cin>>p[i].name ;
    cout << "\nEnter number of cores : " ;
    cin>>p[i].cores;
    cout << "\nEnter frequency in MHz : " ;
    cin>> p[i].freq ;
    cout << "\nEnter cache size in KB : " ;
    cin>>p[i].cache_size;


}

displayProcessor( p, 3);




return 0;
}
void displayProcessor(processor p1[],int size)
{
    for(int i=0;i<size;i++)
{
    cout<<"Displaying processor "<<i<<"data: ";
    cout<<"\n\nprocessor name: "<<p1[i].name;
    cout<<"\nOperating frequencey: "<<p1[i].freq<<"MHz";
    cout<<"\nnumber of cores: "<<p1[i].freq;
    cout<<"\ncache size: "<<p1[i].cache_size<<"KB";

}


}