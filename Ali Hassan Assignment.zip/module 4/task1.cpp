#include <iostream> 

using namespace std; 

struct Student 

{ 

string name; 

int rollNo; 

float cgpa; 

}; 

int main() 

{ 

Student s1; 

s1.name = "Ali Hassan"; 

s1.rollNo = 51; 

s1.cgpa = 3.56; 

cout << "Name : " << s1.name << endl; 

cout << "Roll : " << s1.rollNo << endl; 

cout << "CGPA : " << s1.cgpa << endl; 

return 0; 

} 