#include <iostream>
using namespace std;
struct processor
{
string name;
int cores;
float freq;
int cache_size;

};
int main()
{
processor p1;

cout << "Enter name of the processor : " ; 
cin>>p1.name ;
cout << "\n\nEnter number of cores : " ;
cin>>p1.cores;
cout << "\n\nEnter frequency in MHz : " ;
cin>> p1.freq ;
cout << "\n\nEnter cache size in KB : " ;
cin>> p1.cache_size;

cout<<"processor name: "<<p1.name;
cout<<"\nOperating frequencey: "<<p1.freq<<"MHz";
cout<<"\nnumber of cores: "<<p1.freq;
cout<<"\ncache size: "<<p1.cache_size<<"KB";

return 0;
}