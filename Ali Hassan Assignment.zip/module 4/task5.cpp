#include <iostream>
#include <string>
using namespace std;
struct LogicGate
{
string gateName;
int inputs;
float delay; 
};
LogicGate createGate()
{
 LogicGate gate;
// Assign values to the structure members
 gate.gateName = "AND Gate";
 gate.inputs = 2;
 gate.delay = 3.5;
 // Return the structure
 return gate;
}
int main()
{
   LogicGate g1= createGate();
    cout<<"\nname of the gate: "<<g1.gateName;
    cout<<"\nnumber of inputs: "<<g1.inputs;
    cout<<"\ndelay in ns: "<<g1.delay;
  


}
 